# omnifood

This is a website built under html and css course.

Hello all..... Thankyou for taking a look at this project. This is a training project built completely for learning purpose and to improve my skills. i started learning HTML and CSS technologies and wanted to build a project using just html and css. eventually a tiny bit of javascript was also used for animation purpose.

SITE NAME : omnifood by sravan | a trainee built project.

URL : https://omnifoodsravan.com

This project does not involve any kind of sponserships or bussiness practice. purely built on learning bases.

I am eager to learn new skills every day. feel free to help me with improving this project at any point of time. And also u can have this project files for your own learning curve.

About me:

sravanTG... 
Computer science student...
residing in india.

pls visit my profile section to know more about me.

Email: contact.sravantg@gmail.com

we can discuss project details and improvements and also some tweeks on this mail address.




